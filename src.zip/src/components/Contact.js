const Contact = () => {
    return (
    <div>
      <div className = "container">

        <h4 className="center">Contact
    </h4>
        <p>söz gümüşse sükut altındır.</p>

      </div>
    </div>)
  };

export default Contact;